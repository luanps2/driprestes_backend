const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const handlebars = require('express-handlebars');
const app = express();
const urlencondeParser = bodyParser.urlencoded({ extended: false });

require('./model/index')//Importação do sequelize

const sql = mysql.createConnection({
    host: 'us-cdbr-east-04.cleardb.com',
    user: 'b73be7f80e548e',
    password: '61138a22',
    port: 3306
});

sql.query("use heroku_e27246f552cf39b");

//Template engine
app.engine("handlebars", handlebars({ defaultLayout: 'main' }));
app.set('view engine', 'handlebars');







//Start server
app.listen(3000, function (req, res) {
    console.log('Servidor está rodando!');
});

//Routes and Templates
app.get("/", function (req, res) {
    // res.send("Essa é minha página inicial"); //Mostrar Mensagem simples
    // res.sendFile(__dirname+"/index.html"); //Chamar arquivo externo
    // console.log(req.params.id)
    res.render('index');

});



app.get("/javascript", function (req, res) {
    res.sendFile(__dirname + '/js/javascript.js')
});

app.get("/style", function (req, res) {
    res.sendFile(__dirname + '/css/style.css')
});



app.get("/inserir", function (req, res) {
    res.render("inserir");
})

app.get("/categorias", function (req, res) {
    res.render(__dirname + '/views/layouts/Categoria/categorias');
})

app.get("/inserirCategorias", function (req, res) {
    res.render(__dirname + '/views/layouts/Categoria/inserirCategorias');

})

app.get("/cliente", function (req, res) {
    res.render(__dirname + '/views/layouts/Cliente/cliente');
})

app.get("/pagamento", function (req, res) {
    res.render("pagamento");
})

app.get("/produto", function (req, res) {
    res.render("produto");
})

app.get("/venda", function (req, res) {
    res.render("venda");
})

app.get("/venda_do_produto", function (req, res) {
    res.render("venda");
})

app.get("/vendedor", function (req, res) {
    res.render("vendedor");
})


//controllerForm

app.post("/controllerForm", urlencondeParser, function (req, res) {
    console.log(req.body.name);

   

});
app.post("/controllerFormCategoria", urlencondeParser, function (req, res) {
    console.log(req.body.name);

    sql.query("INSERT INTO categorias values (?,?)", [req.body.categoria_id, req.body.nome_categoria]);
    res.render(__dirname + '/views/controllerFormCategoria')

});

